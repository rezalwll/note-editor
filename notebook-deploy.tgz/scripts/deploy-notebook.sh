#!/usr/bin/env bash
set -euo pipefail

APP_DIR=${APP_DIR:-/var/www/notebook}
ARCHIVE_PATH=${ARCHIVE_PATH:-/root/notebook-deploy.tgz}
DB_NAME=${DB_NAME:-notebook}
DB_USER=${DB_USER:-postgres}
DB_PASS=${DB_PASS:-postgres}
PORT=${PORT:-3000}
BOOTSTRAP_PASSWORD=${BOOTSTRAP_PASSWORD:-change-me-now}
NODE_MAJOR=${NODE_MAJOR:-22}

export DEBIAN_FRONTEND=noninteractive

require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    echo "Run this script as root." >&2
    exit 1
  fi
}

ensure_swap() {
  if swapon --show | grep -q '/swapfile'; then
    return
  fi

  fallocate -l 1G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=1024
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
}

install_packages() {
  apt-get update
  apt-get install -y curl ca-certificates gnupg build-essential postgresql nginx openssl

  if ! command -v node >/dev/null 2>&1; then
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
    apt-get install -y nodejs
  fi

  if ! command -v pm2 >/dev/null 2>&1; then
    npm install -g pm2
  fi
}

prepare_postgres() {
  systemctl enable postgresql
  systemctl restart postgresql

  su - postgres -c "psql -tc \"ALTER USER postgres WITH PASSWORD '${DB_PASS}';\"" >/dev/null || true

  if ! su - postgres -c "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'\"" | grep -q 1; then
    su - postgres -c "createdb '${DB_NAME}'"
  fi
}

deploy_files() {
  if [[ ! -f "${ARCHIVE_PATH}" ]]; then
    echo "Archive not found at ${ARCHIVE_PATH}" >&2
    exit 1
  fi

  mkdir -p "${APP_DIR}"
  find "${APP_DIR}" -mindepth 1 -maxdepth 1 ! -name uploads -exec rm -rf {} +
  tar -xzf "${ARCHIVE_PATH}" -C "${APP_DIR}"
  mkdir -p "${APP_DIR}/uploads"
}

write_env() {
  cat >"${APP_DIR}/.env" <<ENVEOF
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}"
SESSION_SECRET="$(openssl rand -hex 32)"
BOOTSTRAP_PASSWORD="${BOOTSTRAP_PASSWORD}"
UPLOAD_DIR="./uploads"
MAX_UPLOAD_SIZE_MB="10"
ENVEOF
}

build_app() {
  cd "${APP_DIR}"
  npm ci
  npm run prisma:generate
  npm run prisma:deploy

  if ! su - postgres -c "psql -d '${DB_NAME}' -tAc 'SELECT 1 FROM users LIMIT 1'" 2>/dev/null | grep -q 1; then
    npm run prisma:seed
  fi

  npm run build
}

configure_nginx() {
  cat >/etc/nginx/sites-available/notebook <<NGINXEOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:${PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NGINXEOF

  ln -sf /etc/nginx/sites-available/notebook /etc/nginx/sites-enabled/notebook
  rm -f /etc/nginx/sites-enabled/default
  nginx -t
  systemctl enable nginx
  systemctl restart nginx
}

start_app() {
  cd "${APP_DIR}"
  pm2 delete notebook >/dev/null 2>&1 || true
  pm2 start npm --name notebook -- start -- --hostname 127.0.0.1 --port "${PORT}"
  pm2 save
  env PATH="$PATH:/usr/bin" pm2 startup systemd -u root --hp /root >/dev/null
}

print_summary() {
  local server_ip

  server_ip=$(hostname -I | awk '{print $1}')

  echo
  echo "App should be available at: http://${server_ip}"
  echo "App upstream is running on: http://127.0.0.1:${PORT}"
  echo "Public IP expected by you: http://185.18.214.137"
  echo
  pm2 status
  echo
  curl -I "http://127.0.0.1:${PORT}"
}

require_root
ensure_swap
install_packages
prepare_postgres
deploy_files
write_env
build_app
configure_nginx
start_app
print_summary
